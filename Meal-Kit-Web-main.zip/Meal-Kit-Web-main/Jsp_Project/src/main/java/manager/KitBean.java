package manager;

public class KitBean {
	private int kit_id;
	private String kit_kind;
	private String kit_title;
	private int kit_price;
	private int kit_count;
	private String kit_img;
	private String kit_material;
	private String kit_how;
	private String kit_allergy;
	private byte discount_rate;
	
	public int getKit_id() {
		return kit_id;
	}
	public void setKit_id(int kit_id) {
		this.kit_id = kit_id;
	}
	public String getKit_kind() {
		return kit_kind;
	}
	public void setKit_kind(String kit_kind) {
		this.kit_kind = kit_kind;
	}
	public String getKit_title() {
		return kit_title;
	}
	public void setKit_title(String kit_title) {
		this.kit_title = kit_title;
	}
	public int getKit_price() {
		return kit_price;
	}
	public void setKit_price(int kit_price) {
		this.kit_price = kit_price;
	}
	public int getKit_count() {
		return kit_count;
	}
	public void setKit_count(int kit_count) {
		this.kit_count = kit_count;
	}
	public String getKit_img() {
		return kit_img;
	}
	public void setKit_img(String kit_img) {
		this.kit_img = kit_img;
	}
	public String getKit_material() {
		return kit_material;
	}
	public void setKit_material(String kit_material) {
		this.kit_material = kit_material;
	}
	public String getKit_how() {
		return kit_how;
	}
	public void setKit_how(String kit_how) {
		this.kit_how = kit_how;
	}
	public String getKit_allergy() {
		return kit_allergy;
	}
	public void setKit_allergy(String kit_allergy) {
		this.kit_allergy = kit_allergy;
	}
	public byte getDiscount_rate() {
		return discount_rate;
	}
	public void setDiscount_rate(byte discount_rate) {
		this.discount_rate = discount_rate;
	}
	
	
}
