# Meal-Kit-Web
<span>코로나로 인해 대면으로 장을 보지 못하고, 걱정되는 사람들을 위한 Meal-Kit 구매 WEB</span><br>
<span>JSP, MySQL 사용</span>